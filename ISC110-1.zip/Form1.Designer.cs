﻿namespace _110_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            RandomNodesBtn = new Button();
            H_TrunkBtn = new Button();
            exitBtn = new Button();
            label1 = new Label();
            labGridLength = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // RandomNodesBtn
            // 
            RandomNodesBtn.Location = new Point(573, 194);
            RandomNodesBtn.Margin = new Padding(6);
            RandomNodesBtn.Name = "RandomNodesBtn";
            RandomNodesBtn.Size = new Size(199, 46);
            RandomNodesBtn.TabIndex = 0;
            RandomNodesBtn.Text = "Random Nodes";
            RandomNodesBtn.UseVisualStyleBackColor = true;
            RandomNodesBtn.Click += RandomNodesBtn_Click;
            // 
            // H_TrunkBtn
            // 
            H_TrunkBtn.Location = new Point(573, 268);
            H_TrunkBtn.Name = "H_TrunkBtn";
            H_TrunkBtn.Size = new Size(199, 46);
            H_TrunkBtn.TabIndex = 1;
            H_TrunkBtn.Text = "H-Trunk Tree";
            H_TrunkBtn.UseVisualStyleBackColor = true;
            H_TrunkBtn.Click += H_TrunkBtn_Click;
            // 
            // exitBtn
            // 
            exitBtn.Location = new Point(573, 346);
            exitBtn.Name = "exitBtn";
            exitBtn.Size = new Size(199, 46);
            exitBtn.TabIndex = 1;
            exitBtn.Text = "Exit";
            exitBtn.UseVisualStyleBackColor = true;
            exitBtn.Click += exitBtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Location = new Point(589, 20);
            label1.Name = "label1";
            label1.Size = new Size(166, 32);
            label1.TabIndex = 2;
            label1.Text = "總長度(#網格)";
            // 
            // labGridLength
            // 
            labGridLength.Location = new Point(589, 52);
            labGridLength.Name = "labGridLength";
            labGridLength.RightToLeft = RightToLeft.Yes;
            labGridLength.Size = new Size(166, 32);
            labGridLength.TabIndex = 3;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(12, 20);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(550, 550);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(14F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(793, 587);
            Controls.Add(pictureBox1);
            Controls.Add(labGridLength);
            Controls.Add(label1);
            Controls.Add(exitBtn);
            Controls.Add(H_TrunkBtn);
            Controls.Add(RandomNodesBtn);
            Font = new Font("Microsoft JhengHei UI", 18F);
            Margin = new Padding(6);
            Name = "Form1";
            Text = "水平主桿樹連線系統";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button RandomNodesBtn;
        private Button H_TrunkBtn;
        private Button exitBtn;
        private Label label1;
        private Label labGridLength;
        private PictureBox pictureBox1;
    }
}

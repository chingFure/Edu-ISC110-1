namespace _110_1
{
    public partial class Form1 : Form
    {
        public List <Coordinates> points = new List<Coordinates>();//�I�y��
        Random random = new Random(DateTime.Now.Millisecond);//�ü�
        public Coordinates hTrunkMin = new Coordinates(0 , 0);//�I�y�г̤p��
        public Coordinates hTrunkMax = new Coordinates(0 , 0);//�I�y�г̤j��
        private Bitmap chessBoardImage; //�x�s�v��

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// ø�s����
        /// </summary>
        public void printChessBoard()
        {
            if (pictureBox1.Image == null) // �u�b pictureBox1.Image ���Ůɤ~ø�s���
            {
                pictureBox1.Width = ChessBoard.ChessRange.X + ChessBoard.start.X * 2;
                pictureBox1.Height = ChessBoard.ChessRange.Y + ChessBoard.start.Y * 2;
                Bitmap chessBoard = new Bitmap(ChessBoard.ChessRange.X + ChessBoard.start.X * 2, ChessBoard.ChessRange.Y + ChessBoard.start.Y * 2); // �Ыؤ@��200x200�����
                Pen pen = new Pen(Color.Black, 2);
                using (Graphics g = Graphics.FromImage(chessBoard))
                {
                    for (int i = 0; i <= ChessBoard.gridN; i++)
                    {
                        g.DrawLine(pen, ChessBoard.start.X, ChessBoard.start.Y + i * ChessBoard.GridRange.Y, ChessBoard.start.X + ChessBoard.GridRange.X * ChessBoard.gridN, ChessBoard.start.Y + i * ChessBoard.GridRange.Y);
                        g.DrawLine(pen, ChessBoard.start.X + i * ChessBoard.GridRange.X, ChessBoard.start.Y, ChessBoard.start.X + i * ChessBoard.GridRange.X, ChessBoard.start.Y + ChessBoard.GridRange.Y * ChessBoard.gridN);
                    }
                }
                pictureBox1.Image = chessBoard;//�b pictureBox �W��ܦ��
            }
        }

        /// <summary>
        /// ������J
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            printChessBoard();
            generatePoints();
            drawPoints();
            chessBoardImage = (Bitmap)pictureBox1.Image.Clone();
        }

        /// <summary>
        /// ���s�����{��
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// ���s�üƲ��� 7 ���I
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RandomNodesBtn_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
            Form1_Load(sender, e);
        }

        /// <summary>
        /// ���s���� H-Trunk �u
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void H_TrunkBtn_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = (Bitmap)chessBoardImage.Clone();//�b pictureBox1 �W��ܤ��eø�s���Ϲ�
            Graphics g = Graphics.FromImage(pictureBox1.Image);
            DrawHTrunk(new PaintEventArgs(g, pictureBox1.ClientRectangle));//ø�s H-Trunk
        }

        /// <summary>
        /// ø�s H-Trunk �u��
        /// </summary>
        /// <param name="e"></param>
        private void DrawHTrunk(PaintEventArgs e)
        {
            hTrunkMin.X = points.Min(p => p.X);
            hTrunkMax.X = points.Max(p => p.X);
            hTrunkMin.Y = hTrunkMax.Y = (int)Math.Ceiling((double)points.Sum(p => p.Y) / points.Count);
            int gridLength = hTrunkMax.X - hTrunkMin.X;//�p�� H-Trunk �F�u����
            Pen pen = new Pen(Color.Red, ChessBoard.H_TrunkWidth);
            Graphics g = e.Graphics;
            //ø�s H-Trunk �F�u
            g.DrawLine(pen, ChessBoard.pointCoordinates[hTrunkMin.X, hTrunkMin.Y].X + ChessBoard.start.X, ChessBoard.pointCoordinates[hTrunkMin.X, hTrunkMin.Y].Y + ChessBoard.start.Y, ChessBoard.pointCoordinates[hTrunkMax.X, hTrunkMax.Y].X + ChessBoard.start.X, ChessBoard.pointCoordinates[hTrunkMax.X, hTrunkMax.Y].Y + ChessBoard.start.Y);
            foreach (Coordinates pt in points)//ø�s H-Trunk ��u
            {
                g.DrawLine(pen, ChessBoard.pointCoordinates[pt.X, pt.Y].X + ChessBoard.start.X, ChessBoard.pointCoordinates[pt.X, pt.Y].Y + ChessBoard.start.Y, ChessBoard.pointCoordinates[pt.X, pt.Y].X + ChessBoard.start.X, ChessBoard.pointCoordinates[hTrunkMin.X, hTrunkMin.Y].Y + ChessBoard.start.Y);
                gridLength += Math.Abs(pt.Y - hTrunkMin.Y);//�έp H-Trunk ��u����
            }
            labGridLength.Text = gridLength.ToString();
        }

        /// <summary>
        /// ø�s 7 ���I
        /// </summary>
        public void drawPoints()
        {
            using (Graphics g = Graphics.FromImage(pictureBox1.Image))
            {
                foreach (Coordinates point in points)
                {
                    int x = ChessBoard.pointCoordinates[point.X, point.Y].X - ChessBoard.pointR + ChessBoard.start.X;
                    int y = ChessBoard.pointCoordinates[point.X, point.Y].Y - ChessBoard.pointR + ChessBoard.start.Y;
                    int diameter = 2 * ChessBoard.pointR;
                    g.FillEllipse(Brushes.Black, x, y, diameter, diameter);
                }
            }
        }

        /// <summary>
        /// �üƲ����I
        /// </summary>
        public void generatePoints()
        {
            bool[] xNum = Enumerable.Repeat(false, ChessBoard.gridN + 1).ToArray();
            bool[] yNum = Enumerable.Repeat(false, ChessBoard.gridN + 1).ToArray();
            int px, py;
            points.Clear();
            while (points.Count < ChessBoard.pointsNum)//���ͤ����ƪ� x, y �I
            {
                px = random.Next(ChessBoard.coordinatesLimitMin, ChessBoard.coordinatesLimitMax + 1);
                while (xNum[px])
                {
                    px = random.Next(ChessBoard.coordinatesLimitMin, ChessBoard.coordinatesLimitMax + 1);
                }
                py = random.Next(ChessBoard.coordinatesLimitMin, ChessBoard.coordinatesLimitMax + 1);
                while (yNum[py]) // �אּ�ˬd yNum[py]
                {
                    py = random.Next(ChessBoard.coordinatesLimitMin, ChessBoard.coordinatesLimitMax + 1);
                }
                points.Add(new Coordinates(px, py));
                xNum[px] = yNum[py] = true;
            }
        }
    }

    /// <summary>
    /// �y�Щw�q
    /// </summary>
    public class Coordinates
    {
        public int X { get; set; }
        public int Y { get; set; }
        public Coordinates(int x, int y)
        {
            X = x;
            Y = y;
        }
    }

    /// <summary>
    /// �w�q����`��
    /// </summary>
    public class ChessBoard
    {
        public static readonly Coordinates ChessRange = new Coordinates(500, 500);//�e���e��
        public static readonly Coordinates GridRange = new Coordinates(54, 54);//���j����
        public static readonly int gridN = 9;//���� 9 ��
        public static readonly Coordinates start = new Coordinates(20,20);//�e�ѽL�_�I�y��
        public static readonly int coordinatesLimitMin = 2;//�y�нd�򭭨�̤p��
        public static readonly int coordinatesLimitMax = 9;//�y�нd�򭭨�̤j��
        public static readonly int pointsNum = 7;//�I���ƶq�C(�����O�� pointsNum <= coordinatesLimitMax - coordinatesLimitMin)
        public static readonly int pointR = 10;//�y�нd�򭭨�̤j��
        public static readonly int H_TrunkWidth = 6;//H-Trunk �u���e��
        public static readonly Coordinates[,] pointCoordinates;//[10 , 10] �Ӯy���I

        static ChessBoard()
        {
            pointCoordinates = new Coordinates[(gridN + 1) , (gridN + 1)];
            for (int y = 0; y <= gridN; y++)
            {
                for (int x = 0; x <= gridN; x++)
                {
                    pointCoordinates[x , y] = new Coordinates(x * GridRange.X, y * GridRange.Y);//���ͨC�@�Ӻ��u���I
                }
            }
        }
    }
}
